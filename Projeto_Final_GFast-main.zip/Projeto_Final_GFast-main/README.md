# Projeto_Final_GFast

ENVIAR VERSÃO ATUALIZADA PARA GITHUB
Abrir o git bash na pasta onde se encontram os projetos para usar esse caminho
“ls” (para ter a certeza das pastas que existem)
“git add .” (para adicionar tudo existente na pasta)
“git commit -m “descrição”” (para adicionar uma descrição ao commit)
“git push origin” (para enviar tudo para o git)


SACAR VERSÃO ATUALIZADA PARA GITHUB
Abrir o git bash na pasta onde se encontram os projetos para usar esse caminho
“git pull origin”